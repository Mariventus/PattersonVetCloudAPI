﻿namespace ConsumeSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.authenticate = new System.Windows.Forms.Button();
            this.pullData = new System.Windows.Forms.Button();
            this.clientId = new System.Windows.Forms.TextBox();
            this.clientSecret = new System.Windows.Forms.TextBox();
            this.userName = new System.Windows.Forms.TextBox();
            this.resourceOwner = new System.Windows.Forms.CheckBox();
            this.password = new System.Windows.Forms.TextBox();
            this.loginTest = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.unLabel = new System.Windows.Forms.Label();
            this.pwLabel = new System.Windows.Forms.Label();
            this.subscriberId = new System.Windows.Forms.TextBox();
            this.subLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // authenticate
            // 
            this.authenticate.Location = new System.Drawing.Point(632, 12);
            this.authenticate.Name = "authenticate";
            this.authenticate.Size = new System.Drawing.Size(109, 35);
            this.authenticate.TabIndex = 0;
            this.authenticate.Text = "Authenticate";
            this.authenticate.UseVisualStyleBackColor = true;
            this.authenticate.Click += new System.EventHandler(this.authenticate_Click);
            // 
            // pullData
            // 
            this.pullData.Location = new System.Drawing.Point(632, 54);
            this.pullData.Name = "pullData";
            this.pullData.Size = new System.Drawing.Size(109, 34);
            this.pullData.TabIndex = 1;
            this.pullData.Text = "Pull Data";
            this.pullData.UseVisualStyleBackColor = true;
            this.pullData.Click += new System.EventHandler(this.pullData_Click);
            // 
            // clientId
            // 
            this.clientId.Location = new System.Drawing.Point(178, 24);
            this.clientId.Name = "clientId";
            this.clientId.Size = new System.Drawing.Size(405, 22);
            this.clientId.TabIndex = 2;
            // 
            // clientSecret
            // 
            this.clientSecret.Location = new System.Drawing.Point(178, 53);
            this.clientSecret.Name = "clientSecret";
            this.clientSecret.Size = new System.Drawing.Size(405, 22);
            this.clientSecret.TabIndex = 3;
            // 
            // userName
            // 
            this.userName.Location = new System.Drawing.Point(179, 110);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(405, 22);
            this.userName.TabIndex = 4;
            // 
            // resourceOwner
            // 
            this.resourceOwner.AutoSize = true;
            this.resourceOwner.Location = new System.Drawing.Point(178, 82);
            this.resourceOwner.Name = "resourceOwner";
            this.resourceOwner.Size = new System.Drawing.Size(165, 21);
            this.resourceOwner.TabIndex = 5;
            this.resourceOwner.Text = "Use Resource Owner";
            this.resourceOwner.UseVisualStyleBackColor = true;
            this.resourceOwner.CheckedChanged += new System.EventHandler(this.resourceOwner_CheckedChanged);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(178, 138);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(405, 22);
            this.password.TabIndex = 6;
            // 
            // loginTest
            // 
            this.loginTest.Location = new System.Drawing.Point(2, 174);
            this.loginTest.Multiline = true;
            this.loginTest.Name = "loginTest";
            this.loginTest.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.loginTest.Size = new System.Drawing.Size(749, 230);
            this.loginTest.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "ClientId";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Client Secret";
            // 
            // unLabel
            // 
            this.unLabel.AutoSize = true;
            this.unLabel.Location = new System.Drawing.Point(93, 113);
            this.unLabel.Name = "unLabel";
            this.unLabel.Size = new System.Drawing.Size(79, 17);
            this.unLabel.TabIndex = 10;
            this.unLabel.Text = "User Name";
            // 
            // pwLabel
            // 
            this.pwLabel.AutoSize = true;
            this.pwLabel.Location = new System.Drawing.Point(103, 142);
            this.pwLabel.Name = "pwLabel";
            this.pwLabel.Size = new System.Drawing.Size(69, 17);
            this.pwLabel.TabIndex = 11;
            this.pwLabel.Text = "Password";
            // 
            // subscriberId
            // 
            this.subscriberId.Location = new System.Drawing.Point(179, 110);
            this.subscriberId.Name = "subscriberId";
            this.subscriberId.Size = new System.Drawing.Size(404, 22);
            this.subscriberId.TabIndex = 12;
            // 
            // subLabel
            // 
            this.subLabel.AutoSize = true;
            this.subLabel.Location = new System.Drawing.Point(54, 114);
            this.subLabel.Name = "subLabel";
            this.subLabel.Size = new System.Drawing.Size(118, 17);
            this.subLabel.TabIndex = 13;
            this.subLabel.Text = "CustomerNumber";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 416);
            this.Controls.Add(this.subLabel);
            this.Controls.Add(this.subscriberId);
            this.Controls.Add(this.pwLabel);
            this.Controls.Add(this.unLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.loginTest);
            this.Controls.Add(this.password);
            this.Controls.Add(this.resourceOwner);
            this.Controls.Add(this.userName);
            this.Controls.Add(this.clientSecret);
            this.Controls.Add(this.clientId);
            this.Controls.Add(this.pullData);
            this.Controls.Add(this.authenticate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button authenticate;
        private System.Windows.Forms.Button pullData;
        private System.Windows.Forms.TextBox clientId;
        private System.Windows.Forms.TextBox clientSecret;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.CheckBox resourceOwner;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox loginTest;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label unLabel;
        private System.Windows.Forms.Label pwLabel;
        private System.Windows.Forms.TextBox subscriberId;
        private System.Windows.Forms.Label subLabel;
    }
}

