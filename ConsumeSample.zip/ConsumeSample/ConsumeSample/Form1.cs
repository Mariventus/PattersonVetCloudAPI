﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using DataModel;
using Newtonsoft.Json.Linq;
using Thinktecture.IdentityModel.Client;

namespace ConsumeSample
{
    public partial class Form1 : Form
    {
        private TokenResponse _token;
        private DateTime tokenDateTime;
        private readonly string syncUri = "https://syncapi-dev.pattersonvetcloud.com/";
        private readonly string uriString = "https://auth-dev.pattersonvetcloud.com/identity/connect/token";
        public Form1()
        {
            InitializeComponent();
        }
        private TokenResponse Authenticate()
        {
            if (tokenDateTime.AddMinutes(15) <= DateTime.Now)
            {
                var client = new OAuth2Client(new Uri(uriString), clientId.Text, clientSecret.Text);
                if (resourceOwner.Checked)
                {
                    _token =
                        client.RequestResourceOwnerPasswordAsync(userName.Text, password.Text, "PVExServices").Result;
                }
                else
                {
                    _token = client.RequestClientCredentialsAsync("PVExServices").Result;
                }
                tokenDateTime = DateTime.Now;
            }
            return _token;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            showEdits();
        }

        private void authenticate_Click(object sender, EventArgs e)
        {
            var token = Authenticate();
            loginTest.Text = "";
            if (!token.IsError)
            {
                if (token.AccessToken.Contains("."))
                {
                    var parts = token.AccessToken.Split('.');
                    var claims = parts[1];
                    var claimjson = JObject.Parse(Encoding.UTF8.GetString(Base64Url.Decode(claims)));
                    var sb = new StringBuilder();
                    sb.AppendLine("Login Test Passed!");
                    foreach (var claim in claimjson)
                    {
                        sb.AppendFormat("{0}:{1} \r\n", claim.Key, claim.Value);
                    }
                    loginTest.Text = sb.ToString();
                    loginTest.ForeColor = Color.DarkOliveGreen;
                }
            }
            else
            {
                if (token.IsHttpError)
                {
                    var error = string.Format("HttpErrorStatusCode: {0}\r\nHttpErrorReason: {1}",
                        token.HttpErrorStatusCode,
                        token.HttpErrorReason);
                    loginTest.Text = "Login Test Failed\r\n" + error;
                    loginTest.ForeColor = Color.DarkRed;
                }
                else
                {
                    var error = string.Format("Error: {0}\r\nJson: {1}",
                        token.Error,
                        token.Json);
                    loginTest.Text = "Login Test Failed\r\n" + error;
                    loginTest.ForeColor = Color.DarkRed;
                }
            }
        }

        private void showEdits()
        {
            unLabel.Visible = resourceOwner.Checked;
            userName.Visible = resourceOwner.Checked;
            pwLabel.Visible = resourceOwner.Checked;
            password.Visible = resourceOwner.Checked;
            subscriberId.Visible = !resourceOwner.Checked;
            subLabel.Visible = !resourceOwner.Checked;
        }
        private void resourceOwner_CheckedChanged(object sender, EventArgs e)
        {
            showEdits();
        }

        private string getCustomerFromToken(TokenResponse token)
        {
            var customer = "";
            if (resourceOwner.Checked)
            {
                if (!token.IsError)
                {
                    if (token.AccessToken.Contains("."))
                    {
                        var parts = token.AccessToken.Split('.');
                        var claims = parts[1];
                        var claimjson = JObject.Parse(Encoding.UTF8.GetString(Base64Url.Decode(claims)));
                        var customernumber = claimjson.GetValue("cust_num");
                        if (customernumber != null)
                        {
                            customer = customernumber.ToString();
                        }
                    }
                }
            }
            else
            {
                customer = subscriberId.Text;
            }
            
            return customer;
        }

        private void pullData_Click(object sender, EventArgs e)
        {
            var token = Authenticate();
            var customer = getCustomerFromToken(token);

            var syncs = new List<Sync>();
            loginTest.Text = "";
            using (var svcClient = new HttpClient())
            {
                svcClient.BaseAddress = new Uri(syncUri);
                svcClient.DefaultRequestHeaders.Accept.Clear();
                svcClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                svcClient.SetBearerToken(token.AccessToken);
                svcClient.DefaultRequestHeaders.Add("customerId", customer);

                // New code:
                HttpResponseMessage response = svcClient.GetAsync("api/Syncs").Result;
                if (response.IsSuccessStatusCode)
                {
                    syncs = response.Content.ReadAsAsync<List<Sync>>().Result;
                    loginTest.Text = string.Format("{0} syncs retrieved", syncs.Count);
                }
                if (syncs.Count > 0)
                {
                    var syncid = syncs.FirstOrDefault().SyncID;
                    svcClient.DefaultRequestHeaders.Add("sessionId", syncid);
                    response = svcClient.GetAsync("api/Clients").Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var clients = response.Content.ReadAsAsync<List<Client>>().Result;
                        loginTest.Text = string.Format("{0}\r\n{1} clients retrieved from sync {2}", loginTest.Text ,clients.Count, syncid);
                    }

                    response = svcClient.GetAsync("api/Patients").Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var patients = response.Content.ReadAsAsync<List<Patient>>().Result;
                        loginTest.Text = string.Format("{0}\r\n{1} patients retrieved from sync {2}", loginTest.Text, patients.Count, syncid);
                    }

                    response = svcClient.GetAsync("api/CodeEntities").Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var codes = response.Content.ReadAsAsync<List<CodeEntity>>().Result;
                        loginTest.Text = string.Format("{0}\r\n{1} codes retrieved from sync {2}", loginTest.Text, codes.Count, syncid);
                    }
                }
            }

            loginTest.Text = string.Format("{0}\r\nDone", loginTest.Text);
        }
    }
}
