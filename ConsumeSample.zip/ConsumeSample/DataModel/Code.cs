using System;

namespace DataModel
{
    public class CodeEntity
    {
        public CodeEntity()
        {
            RowKey = 0;
        }
        public string CodeType { get; set; }
        public string Code { get; set; }
        public string CodeDescription { get; set; }
        public string CodeCategory { get; set; }
        public string CodeCategoryDescription { get; set; }
        public decimal? BasePrice { get; set; }
        public bool? IsGroup { get; set; }
        public bool Inactive { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}