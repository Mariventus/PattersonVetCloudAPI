using System;

namespace DataModel
{
    public class Referral
    {
        public Referral()
        {
            RowKey = 0;
        }
        public string ReferredId { get; set; }
        public string ReferralSourceId { get; set; }
        public string ReferralSourceParentId { get; set; }
        public string ReferredEntityType { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? EnteredDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}