using System;

namespace DataModel
{
    public class LabPanel
    {
        public LabPanel()
        {
            RowKey = 0;
        }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public DateTime? ApiRemovedDate { get; set; }
        public string CodeId { get; set; }
        public string Code { get; set; }
        public string CodeDescription { get; set; }
        public string Comments { get; set; }
        public DateTime? Date { get; set; }
        public string Description { get; set; }
        public bool? IsPending { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public string ResourceId { get; set; }
        public string ResourceName { get; set; }
        public string SiteId { get; set; }
        public string Status { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}