using System;

namespace DataModel
{
    public class Prescription
    {
        public Prescription()
        {
            RowKey = 0;
        }
        public string CodeId { get; set; }
        public string Code { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public string Description { get; set; }
        public string ProviderId { get; set; }
        public string ProviderName { get; set; }
        public string Filler { get; set; }
        public DateTime? IssuedDate { get; set; }
        public DateTime? FillDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public decimal Quantity { get; set; }
        public string TransactionId { get; set; }
        public int TotalRefills { get; set; }
        public int CurrentRefillNumber { get; set; }
        public string PrescriptionNumber { get; set; }
        public string Instructions { get; set; }
        public bool? IsVoided { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}