using System;

namespace DataModel
{
    public class Phone
    {
        public Phone()
        {
            RowKey = 0;
        }
        public string Type { get; set; }
        public bool? IsPrimary { get; set; }
        public string Number { get; set; }
        public string RelationshipId { get; set; }
        public string RelationshipPmsId { get; set; }
        public string RelationshipEntity { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}