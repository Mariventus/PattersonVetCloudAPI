using System;

namespace DataModel
{
    public class Client
    {
        public Client()
        {
            RowKey = 0;
        }
        public string PmsId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string SignificantOther { get; set; }
        public DateTime? EnteredDate { get; set; }
        public bool? Deleted { get; set; }
        public bool? Inactive { get; set; }
        public bool? SuspendReminders { get; set; }
        public bool? EmailReminders { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public string ClientTypeCode { get; set; }
        public string ClientTypeDescription { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}