using System;

namespace DataModel
{
    public class Address
    {
        public Address()
        {
            RowKey = 0;
        }
        public string Type { get; set; }
        public bool? IsPrimary { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string StateProvince { get; set; }
        public string PostalCode { get; set; }
        public string RelationshipId { get; set; }
        public string RelationshipPmsId { get; set; }
        public string RelationshipEntity { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public Int64 RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}