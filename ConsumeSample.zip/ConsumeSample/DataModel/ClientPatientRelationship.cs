using System;
using Newtonsoft.Json;

namespace DataModel
{
   
    public class ClientPatientRelationship
    {
        public ClientPatientRelationship()
        {
            RowKey = 0;
        }
        [JsonProperty("TypeValue")]
        public string Type { get; set; }
        public string ClientId { get; set; }
        public string ClientPmsId { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public bool? IsPrimary { get; set; }
        public decimal? Percentage { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}