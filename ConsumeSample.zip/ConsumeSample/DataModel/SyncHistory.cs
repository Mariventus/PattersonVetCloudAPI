using System;

namespace DataModel
{
    public class SyncHistory
    {
        public long RowKey { get; set; }
        public string SubscriberId { get; set; }
        public string EntityName { get; set; }
        public string SyncId { get; set; }
        public string ExtractPluginVersion { get; set; }
        public string PMS { get; set; }
        public long RecordCount { get; set; }
        public DateTime? SyncTime { get; set; }
        public long CheckSum { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public string Id { get; set; }
    }
}