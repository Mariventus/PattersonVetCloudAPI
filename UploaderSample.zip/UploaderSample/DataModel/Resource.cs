using System;

namespace DataModel
{
    public class Resource
    {
        public Resource()
        {
            RowKey = 0;
        }
        public string PmsId { get; set; }
        public string Type { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string FullName { get; set; }
        public bool? IsUser { get; set; }
        public bool? IsDoctor { get; set; }
        public bool? Inactive { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}