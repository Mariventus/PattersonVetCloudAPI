using System;

namespace DataModel
{
    public class Invoice
    {
        public Invoice()
        {
            RowKey = 0;
        }
        public string Number { get; set; }
        public DateTime? DateTime { get; set; }
        public string ClientId { get; set; }
        public string ClientPmsId { get; set; }
        public string ProviderId { get; set; }
        public string ProviderPmsId { get; set; }
        public decimal? Amount { get; set; }
        public decimal? BalanceDue { get; set; }
        public decimal? DiscountAmount { get; set; }
        public decimal? AdjustmentAmount { get; set; }
        public decimal? TotalTaxAmount { get; set; }
        public string PmsStatus { get; set; }
        public bool? IsComplete { get; set; }
        public bool IsPaid { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}