using System;
using Newtonsoft.Json;

namespace DataModel
{
    [JsonObject(MemberSerialization.Fields)]
    public class LabTestResult
    {
        public LabTestResult()
        {
            RowKey = 0;
        }
        public string LabPanelId { get; set; }
        [JsonProperty("DateValue")]
        public DateTime Date { get; set; }
        public int? Sequence { get; set; }
        public string TestName { get; set; }
        public string UnitOfMeasure { get; set; }
        public string Result { get; set; }
        public string ResultType { get; set; }
        public string Indicator { get; set; }
        public string ReferenceCriticalLow { get; set; }
        public string ReferenceCriticalHigh { get; set; }
        public string ReferenceLow { get; set; }
        public string ReferenceHigh { get; set; }
        public string ReferenceRange { get; set; }
        public string Comments { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}