using System;

namespace DataModel
{
    public class PatientCustomField
    {
        public PatientCustomField()
        {
            RowKey = 0;
        }
        public string Name { get; set; }
        public string Value { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}