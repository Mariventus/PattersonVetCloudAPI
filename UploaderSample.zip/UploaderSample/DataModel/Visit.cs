using System;

namespace DataModel
{
    public class Visit
    {
        public Visit()
        {
            RowKey = 0;
        }
        public string Type { get; set; }
        public string ClientId { get; set; }
        public string ClientPmsId { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public DateTime? DateEntered { get; set; }
        public string EnteredByResourceId { get; set; }
        public DateTime? CheckInDate { get; set; }
        public DateTime? CheckOutDate { get; set; }
        public string Reason { get; set; }
        public bool? IsFinalized { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}