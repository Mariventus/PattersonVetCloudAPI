using System;

namespace DataModel
{
    public class Transaction
    {
        public Transaction()
        {
            RowKey = 0;
        }
        public string Type { get; set; }
        public string ClientId { get; set; }
        public string ClientPmsId { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public DateTime? TransactionDate { get; set; }
        public decimal Sequence { get; set; }
        public string Code { get; set; }
        public string CodeId { get; set; }
        public bool Deleted { get; set; }
        public string Description { get; set; }
        public decimal? Quantity { get; set; }
        public decimal? Amount { get; set; }
        public string ProviderId { get; set; }
        public string ProviderName { get; set; }
        public bool? IsPayment { get; set; }
        public bool? IsPosted { get; set; }
        public string Comments { get; set; }
        public string InvoiceId { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}