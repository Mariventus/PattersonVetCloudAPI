using System;

namespace DataModel
{
    public class Schedule
    {
        public Schedule()
        {
            RowKey = 0;
        }
        public string Source { get; set; }
        public string Type { get; set; }
        public string ClientId { get; set; }
        public string ClientPmsId { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public bool Deleted { get; set; }
        public DateTime? Date { get; set; }
        public int Duration { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
        public string ResourceId { get; set; }
        public string ResourceName { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}