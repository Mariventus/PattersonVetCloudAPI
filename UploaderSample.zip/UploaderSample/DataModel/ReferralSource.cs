using System;

namespace DataModel
{
    public class ReferralSource
    {
        public ReferralSource()
        {
            RowKey = 0;
        }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public string PatientReferralSourceId { get; set; }
        public string SiteId { get; set; }
        public string Type { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}