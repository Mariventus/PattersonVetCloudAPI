using System;

namespace DataModel
{
    public class Sync
    {
        public long Id { get; set; }
        public string SubscriberId { get; set; }
        public string SyncID { get; set; }
        public bool Status { get; set; }
        public decimal ExtractPluginVersion { get; set; }
        public string PMS { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
    }
}