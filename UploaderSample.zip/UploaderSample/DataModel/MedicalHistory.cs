using System;

namespace DataModel
{
    public class MedicalHistory
    {
        public MedicalHistory()
        {
            RowKey = 0;
        }
        public string Type { get; set; }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public DateTime HistoryDate { get; set; }
        public string ShortDescription { get; set; }
        public string Details { get; set; }
        public string Comments { get; set; }
        public string ResourceId { get; set; }
        public string ResourceName { get; set; }
        public string TemplateId { get; set; }
        public bool? IsPending { get; set; }
        public string SiteId { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}