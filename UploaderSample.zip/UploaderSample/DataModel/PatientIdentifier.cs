using System;

namespace DataModel
{
    public class PatientIdentifier
    {
        public PatientIdentifier()
        {
            RowKey = 0;
        }
        public string PatientId { get; set; }
        public string PatientPmsId { get; set; }
        public string Type { get; set; }
        public string SubType { get; set; }
        public DateTime? Date { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string Identifier { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}