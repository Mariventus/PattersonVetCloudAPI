using System;

namespace DataModel
{
    public class Site
    {
        public Site()
        {
            RowKey = 0;
        }
        public string PmsId { get; set; }
        public string Name { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}