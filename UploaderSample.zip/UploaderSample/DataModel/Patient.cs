using System;

namespace DataModel
{
    public class Patient
    {
        public Patient()
        {
            RowKey = 0;
        }
        public string PmsId { get; set; }
        public string ClientPmsId { get; set; }
        public string Name { get; set; }
        public string Species { get; set; }
        public string SpeciesDescription { get; set; }
        public string Breed { get; set; }
        public string BreedDescription { get; set; }
        public string Color { get; set; }
        public string ColorDescription { get; set; }
        public string Gender { get; set; }
        public string GenderDescription { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public DateTime? DateOfDeath { get; set; }
        public DateTime? EnteredDate { get; set; }
        public bool Deleted { get; set; }
        public bool? IsDeceased { get; set; }
        public bool? Inactive { get; set; }
        public decimal? CurrentWeight { get; set; }
        public string CurrentWeightUnit { get; set; }
        public DateTime? LastTransactionDate { get; set; }
        public string SiteId { get; set; }
        public string Rabies { get; set; }
        public string MicroChip { get; set; }
        public string LostAndFoundSerial { get; set; }
        public bool? SuspendReminders { get; set; }
        public DateTime ApiCreateDate { get; set; }
        public DateTime? ApiLastChangeDate { get; set; }
        public long CheckSum { get; set; }
        public long RowKey { get; set; }
        public string Id { get; set; }
        public string SyncId { get; set; }
        public string SubscriberId { get; set; }
    }
}