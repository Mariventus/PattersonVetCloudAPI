﻿namespace UploaderSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.authButton = new System.Windows.Forms.Button();
            this.clientId = new System.Windows.Forms.TextBox();
            this.clientSecret = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.resourceOwner = new System.Windows.Forms.CheckBox();
            this.userName = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.loginTest = new System.Windows.Forms.TextBox();
            this.upload = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // authButton
            // 
            this.authButton.Location = new System.Drawing.Point(531, 12);
            this.authButton.Name = "authButton";
            this.authButton.Size = new System.Drawing.Size(106, 38);
            this.authButton.TabIndex = 0;
            this.authButton.Text = "Authenticate";
            this.authButton.UseVisualStyleBackColor = true;
            this.authButton.Click += new System.EventHandler(this.authButton_Click);
            // 
            // clientId
            // 
            this.clientId.Location = new System.Drawing.Point(148, 9);
            this.clientId.Name = "clientId";
            this.clientId.Size = new System.Drawing.Size(336, 22);
            this.clientId.TabIndex = 3;
            // 
            // clientSecret
            // 
            this.clientSecret.Location = new System.Drawing.Point(148, 38);
            this.clientSecret.Name = "clientSecret";
            this.clientSecret.Size = new System.Drawing.Size(336, 22);
            this.clientSecret.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "ClientId:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "ClientSecret:";
            // 
            // resourceOwner
            // 
            this.resourceOwner.AutoSize = true;
            this.resourceOwner.Location = new System.Drawing.Point(148, 67);
            this.resourceOwner.Name = "resourceOwner";
            this.resourceOwner.Size = new System.Drawing.Size(165, 21);
            this.resourceOwner.TabIndex = 7;
            this.resourceOwner.Text = "Use Resource Owner";
            this.resourceOwner.UseVisualStyleBackColor = true;
            // 
            // userName
            // 
            this.userName.Location = new System.Drawing.Point(148, 95);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(336, 22);
            this.userName.TabIndex = 8;
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(148, 124);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(336, 22);
            this.password.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "User Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(69, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Password:";
            // 
            // loginTest
            // 
            this.loginTest.Location = new System.Drawing.Point(13, 152);
            this.loginTest.Multiline = true;
            this.loginTest.Name = "loginTest";
            this.loginTest.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.loginTest.Size = new System.Drawing.Size(633, 224);
            this.loginTest.TabIndex = 12;
            // 
            // upload
            // 
            this.upload.Location = new System.Drawing.Point(531, 56);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(106, 38);
            this.upload.TabIndex = 13;
            this.upload.Text = "Upload";
            this.upload.UseVisualStyleBackColor = true;
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 388);
            this.Controls.Add(this.upload);
            this.Controls.Add(this.loginTest);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.password);
            this.Controls.Add(this.userName);
            this.Controls.Add(this.resourceOwner);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.clientSecret);
            this.Controls.Add(this.clientId);
            this.Controls.Add(this.authButton);
            this.Name = "Form1";
            this.Text = "Patterson Vet Cloud Sample Uploader";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button authButton;
        private System.Windows.Forms.TextBox clientId;
        private System.Windows.Forms.TextBox clientSecret;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox resourceOwner;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox loginTest;
        private System.Windows.Forms.Button upload;
    }
}

