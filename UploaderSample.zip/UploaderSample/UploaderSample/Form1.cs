﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using DataModel;
using Newtonsoft.Json.Linq;
using Thinktecture.IdentityModel.Client;

namespace UploaderSample
{
    public partial class Form1 : Form
    {
        private TokenResponse _token;
        private DateTime tokenDateTime;
        private readonly string uploadUri = "https://api-dev.pattersonvetcloud.com/";
        private readonly string uriString = "https://auth-dev.pattersonvetcloud.com/identity/connect/token";

        public Form1()
        {
            InitializeComponent();
        }

        private TokenResponse Authenticate()
        {
            if (tokenDateTime.AddMinutes(15) <= DateTime.Now)
            {
                var client = new OAuth2Client(new Uri(uriString), clientId.Text, clientSecret.Text);
                if (resourceOwner.Checked)
                {
                    _token =
                        client.RequestResourceOwnerPasswordAsync(userName.Text, password.Text, "PVExServices").Result;
                }
                else
                {
                    _token = client.RequestClientCredentialsAsync("PVExServices").Result;
                }
                tokenDateTime = DateTime.Now;
            }
            return _token;
        }

        private void authButton_Click(object sender, EventArgs e)
        {
            var token = Authenticate();
            loginTest.Text = "";
            if (!token.IsError)
            {
                if (token.AccessToken.Contains("."))
                {
                    var parts = token.AccessToken.Split('.');
                    var claims = parts[1];
                    var claimjson = JObject.Parse(Encoding.UTF8.GetString(Base64Url.Decode(claims)));
                    var sb = new StringBuilder();
                    sb.AppendLine("Login Test Passed!");
                    foreach (var claim in claimjson)
                    {
                        sb.AppendFormat("{0}:{1} \r\n", claim.Key, claim.Value);
                    }
                    loginTest.Text = sb.ToString();
                    loginTest.ForeColor = Color.DarkOliveGreen;
                }
            }
            else
            {
                if (token.IsHttpError)
                {
                    var error = string.Format("HttpErrorStatusCode: {0}\r\nHttpErrorReason: {1}",
                        token.HttpErrorStatusCode,
                        token.HttpErrorReason);
                    loginTest.Text = "Login Test Failed\r\n" + error;
                    loginTest.ForeColor = Color.DarkRed;
                }
                else
                {
                    var error = string.Format("Error: {0}\r\nJson: {1}",
                        token.Error,
                        token.Json);
                    loginTest.Text = "Login Test Failed\r\n" + error;
                    loginTest.ForeColor = Color.DarkRed;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void upload_Click(object sender, EventArgs e)
        {
            var token = Authenticate();
            var customer = getCustomerFromToken(token);
            if (string.IsNullOrEmpty(customer))
            {
                MessageBox.Show("You must use resource owner credentials to perform an upload");
            }
            else
            {
                // create a sync session
                var sync = new Sync
                {
                    SubscriberId = customer,
                    SyncID = Guid.NewGuid().ToString(),
                    StartTime = DateTime.Now,
                    PMS = "MockData",
                    ExtractPluginVersion = 1.00M,
                    Status = true,
                    Id = 0,
                };
                // upload data elements
                uploadAddresses(sync.SyncID, customer);
                uploadPhones(sync.SyncID, customer);
                uploadEmails(sync.SyncID, customer);
                uploadClients(sync.SyncID, customer);
                uploadPatients(sync.SyncID, customer);
                uploadRelationships(sync.SyncID, customer);
                uploadCodes(sync.SyncID, customer);
                sync.EndTime = DateTime.Now;

                // finalize sync session
                using (var svcClient = new HttpClient())
                {
                    token = Authenticate();
                    svcClient.BaseAddress = new Uri(uploadUri);
                    svcClient.DefaultRequestHeaders.Accept.Clear();
                    svcClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    svcClient.DefaultRequestHeaders.Add("sessionId", sync.SyncID);
                    svcClient.DefaultRequestHeaders.Add("customerId", sync.SubscriberId);
                    svcClient.SetBearerToken(token.AccessToken);
                    var url = "api/Sync";
                    var response = svcClient.PostAsJsonAsync(url, sync).Result;
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new Exception(string.Format("Status code:{0}\r\nResponse: {1}", response.StatusCode,
                            response));
                    }
                    loginTest.Text = string.Format("{0}\r\nSync Completed", loginTest.Text);
                }
            }
        }

        public int UploadObjects<T>(List<T> objects, string sessionId, string customerId, string typeName)
        {
            try
            {
                var uploaded = false;

                // upload the data objects
                using (var svcClient = new HttpClient())
                {
                    var token = Authenticate();
                    svcClient.BaseAddress = new Uri(uploadUri);
                    svcClient.DefaultRequestHeaders.Accept.Clear();
                    svcClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    svcClient.DefaultRequestHeaders.Add("sessionId", sessionId);
                    svcClient.DefaultRequestHeaders.Add("customerId", customerId);
                    svcClient.SetBearerToken(token.AccessToken);
                    var url = string.Format("api/{0}Batch", typeName);
                    var response = svcClient.PostAsJsonAsync(url, objects).Result;
                    if (!response.IsSuccessStatusCode)
                    {
                        throw new Exception(string.Format("Status code:{0}\r\nResponse: {1}", response.StatusCode,
                            response));
                    }
                    uploaded = true;
                    loginTest.Text = string.Format("{0}\r\n{1} uploaded", loginTest.Text, typeName);
                }

                // create and upload the sync history object
                if (uploaded)
                {
                    var hist = new SyncHistory
                    {
                        ApiCreateDate = DateTime.Now,
                        ApiLastChangeDate = DateTime.Now,
                        CheckSum = 0,
                        EntityName = typeName,
                        ExtractPluginVersion = "1.00",
                        Id = Guid.NewGuid().ToString(),
                        PMS = "MockData",
                        RecordCount = 10,
                        RowKey = 0,
                        SubscriberId = customerId,
                        SyncId = sessionId,
                        SyncTime = DateTime.Now
                    };
                    using (var svcClient = new HttpClient())
                    {
                        var token = Authenticate();
                        svcClient.BaseAddress = new Uri(uploadUri);
                        svcClient.DefaultRequestHeaders.Accept.Clear();
                        svcClient.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        svcClient.DefaultRequestHeaders.Add("sessionId", sessionId);
                        svcClient.DefaultRequestHeaders.Add("customerId", customerId);
                        svcClient.SetBearerToken(token.AccessToken);
                        var url = "api/SyncHistory";
                        var response = svcClient.PostAsJsonAsync(url, hist).Result;
                        if (!response.IsSuccessStatusCode)
                        {
                            throw new Exception(string.Format("{0}: {1}", response.StatusCode, response));
                        }
                        Thread.Yield();
                    }
                }
            }
            catch (Exception e)
            {
                loginTest.Text = string.Format("{0}\r\n{1} failed {2}", loginTest.Text, typeName, e.Message);
            }
            return 1;
        }

        private string getCustomerFromToken(TokenResponse token)
        {
            var customer = "";
            if (!token.IsError)
            {
                if (token.AccessToken.Contains("."))
                {
                    var parts = token.AccessToken.Split('.');
                    var claims = parts[1];
                    var claimjson = JObject.Parse(Encoding.UTF8.GetString(Base64Url.Decode(claims)));
                    var customernumber = claimjson.GetValue("cust_num");
                    if (customernumber != null)
                    {
                        customer = customernumber.ToString();
                    }
                }
            }
            return customer;
        }

        private void uploadAddresses(string session, string customer)
        {
            var objects = new List<Address>();
            var count = 0;
            while (count < 10)
            {
                var add = new Address
                {
                    AddressLine1 = string.Format("address1 - {0}", count),
                    AddressLine2 = string.Format("address2 - {0}", count),
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    City = string.Format("city - {0}{1}", count == 3 ? "update" : "", count),
                    Id = string.Format("refclient|mockclient|{0}", count),
                    IsPrimary = true,
                    PostalCode = string.Format("{0}", count),
                    RelationshipEntity = "Client",
                    RelationshipId = string.Format("mockclient{0}", count),
                    RelationshipPmsId = string.Format("mockclient{0}", count),
                    StateProvince = "test",
                    SubscriberId = customer,
                    SyncId = session,
                    Type = "mock",
                    CheckSum = 0
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "Address");
        }

        private void uploadPhones(string session, string customer)
        {
            var objects = new List<Phone>();
            var count = 0;
            while (count < 10)
            {
                var add = new Phone
                {
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    Id = string.Format("refclient|mockclient|{0}", count),
                    IsPrimary = true,
                    RelationshipEntity = "Client",
                    RelationshipId = string.Format("mockclient{0}", count),
                    RelationshipPmsId = string.Format("mockclient{0}", count),
                    SubscriberId = customer,
                    SyncId = session,
                    Type = "mock",
                    CheckSum = 0,
                    Number = objects.Count.ToString().PadRight(10, '0')
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "Phone");
        }

        private void uploadEmails(string session, string customer)
        {
            var objects = new List<Email>();
            var count = 0;
            while (count < 10)
            {
                var add = new Email
                {
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    Id = string.Format("refclient|mockclient|{0}", count),
                    IsPrimary = true,
                    RelationshipEntity = "Client",
                    RelationshipId = string.Format("mockclient{0}", count),
                    RelationshipPmsId = string.Format("mockclient{0}", count),
                    SubscriberId = customer,
                    SyncId = session,
                    Type = "mock",
                    CheckSum = 0,
                    Address = string.Format("mockemail{0}@mock.kom", count)
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "Email");
        }

        private void uploadClients(string session, string customer)
        {
            var objects = new List<Client>();
            var count = 0;
            while (count < 10)
            {
                var add = new Client
                {
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    Id = string.Format("mocksite|client{0}", count),
                    SubscriberId = customer,
                    SyncId = session,
                    CheckSum = 0,
                    Deleted = false,
                    EmailReminders = true,
                    SuspendReminders = true,
                    EnteredDate = DateTime.Today.AddDays(-360),
                    FirstName = string.Format("FirstName{0}", count),
                    LastName = string.Format("LastName{0}", count),
                    PmsId = string.Format("client{0}", count),
                    ClientTypeCode = string.Format("{0}", count),
                    ClientTypeDescription = string.Format("description{0}", count),
                    Inactive = false,
                    SignificantOther = string.Format("SignificantOther{0}", count),
                    SiteId = "mocksite"
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "Client");
        }

        private void uploadPatients(string session, string customer)
        {
            var objects = new List<Patient>();
            var count = 0;
            while (count < 10)
            {
                var add = new Patient
                {
                    Id = string.Format("patient{0}", count),
                    PmsId = string.Format("patient{0}", count),
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    SubscriberId = customer,
                    SyncId = session,
                    EnteredDate = DateTime.Now,
                    Deleted = false,
                    DateOfDeath = null,
                    DateOfBirth = DateTime.Now.AddYears(-3),
                    ClientPmsId = string.Format("client{0}", count),
                    CurrentWeightUnit = "CurrentWeightUnit",
                    CurrentWeight = objects.Count,
                    ColorDescription = "ColorDescription",
                    Color = "Color",
                    Gender = "Gender",
                    BreedDescription = "BreedDescription",
                    Breed = "Breed",
                    GenderDescription = "GenderDescription",
                    Inactive = false,
                    IsDeceased = false,
                    LastTransactionDate = DateTime.Now,
                    Name = "Name",
                    Species = "Species",
                    SpeciesDescription = "SpeciesDescription",
                    SiteId = "mocksite",
                    SuspendReminders = false,
                    CheckSum = 455904
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "Patient");
        }

        private void uploadRelationships(string session, string customer)
        {
            var objects = new List<ClientPatientRelationship>();
            var count = 0;
            while (count < 10)
            {
                var add = new ClientPatientRelationship
                {
                    Id = string.Format("client{0}|patient{0}", count),
                    Type = "Owner",
                    ClientId = string.Format("client{0}", count),
                    ClientPmsId = string.Format("client{0}", count),
                    PatientId = string.Format("patient{0}", count),
                    PatientPmsId = string.Format("patient{0}", count),
                    IsPrimary = true,
                    Percentage = 100,
                    StartDate = DateTime.Now.AddDays(-365),
                    EndDate = null,
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    SubscriberId = customer,
                    SyncId = session
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "ClientPatientRelationship");
        }

        private void uploadCodes(string session, string customer)
        {
            var objects = new List<CodeEntity>();
            var count = 0;
            while (count < 10)
            {
                var add = new CodeEntity
                {
                    ApiCreateDate = DateTime.Now,
                    ApiLastChangeDate = null,
                    Id = string.Format("CodeEntity{0}", count),
                    SubscriberId = customer,
                    SyncId = session,
                    CheckSum = 0,
                    Inactive = false,
                    SiteId = "mocksite",
                    BasePrice = 99,
                    Code = string.Format("code{0}", count),
                    CodeCategory = "mockcategory",
                    CodeCategoryDescription = "mock category",
                    CodeDescription = "mock description",
                    CodeType = "mockcode",
                    IsGroup = false
                };
                count++;
                objects.Add(add);
            }
            UploadObjects(objects, session, customer, "Code");
        }
    }
}